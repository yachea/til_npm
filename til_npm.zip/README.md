# 구글 로그인

## 1. GCP (구글 클라우드 플랫폼) 서비스 신청

- https://console.cloud.google.com
- tps://iwoohaha.tistory.com/318

## 2. `.env` 내용 작성

- 접두어 주의 `REACT_APP_`

```txt
REACT_APP_GOOGLE_ACLIENT_KEY=키
REACT_APP_GOOGLE_SECRET_KEY=키
```

## 3. 폴더 및 파일 구조

- /src/google 폴더 생성
- /src/google/googleapi.js 폴더 생성

```js
const GOOGLE_CLIENT_ID = process.env.REACT_APP_GOOGLE_CLIENT_KEY;
const GOOGLE_REDIRECT_URI = "http://localhost:3000/member/google";
// 구글 로그인시 활용
export const getGoogleLoginLink = () => {
  window.location.href = `https://accounts.google.com/o/oauth2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${GOOGLE_REDIRECT_URI}&response_type=code&scope=openid email profile`;
};

export const getGoogleToken = async code => {
  const REST_API_KEY = GOOGLE_CLIENT_ID;
  const REDIRECT_URI = GOOGLE_REDIRECT_URI;
  const SECRET_KEY = process.env.REACT_APP_GOOGLE_SECRET_KEY;
  const response = await fetch(
    `https://oauth2.googleapis.com/token?grant_type=authorization_code&client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URI}&client_secret=${SECRET_KEY}&code=${code}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
      },
    },
  );
  return response.json();
};

export const getGoogleUserInfo = async accessToken => {
  try {
    const response = await fetch(
      "https://www.googleapis.com/oauth2/v2/userinfo",
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    );

    if (!response.ok) {
      throw new Error("Failed to fetch Google user info");
    }

    const userData = await response.json();
    return userData;
  } catch (error) {
    console.error("Error fetching Google user info:", error);
    return null;
  }
};
```

## 4. 로그인 후 이동페이지 만들기

- /src/pages/member/AfterGoogle.jsx 생성

## 5. 라우터 구성

- App.jsx

```jsx
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import After from "./pages/member/After";
import AfterGoogle from "./pages/member/AfterGoogle";

function App() {
  return (
    <Router>
      <LoginPage />
      <Routes>
        <Route path="member/kko" element={<After />}></Route>
        <Route path="member/google" element={<AfterGoogle />}></Route>
      </Routes>
    </Router>
  );
}

export default App;
```

## 6. 구글로그인 버튼 배치
- /src/pages/LoginPage.jsx